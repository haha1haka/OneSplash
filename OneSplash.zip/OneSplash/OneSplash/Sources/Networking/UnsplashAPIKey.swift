import Foundation

enum UnsplashAPIKey {
    static let appKey = "yyQ4PqsmUlRItIZVR2fLsSpNUO_xrZpli9xxqBqA5uk"
    static let secretKey = "waEU78UTNwV7rMarK2523uusNLQM4z0oKUzvJdBIdj0"
}
