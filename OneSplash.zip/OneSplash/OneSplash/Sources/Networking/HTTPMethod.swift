import Foundation

enum HTTPMethod: String {
    case get, post, put, delete
}
